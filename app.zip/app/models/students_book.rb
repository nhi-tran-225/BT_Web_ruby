class StudentsBook < ApplicationRecord
end
